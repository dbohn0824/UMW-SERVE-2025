<?php


session_cache_expire(30);
session_start();

?>

<!DOCTYPE html>
<html>
    <p style="text-align: center; margin-top: 200px;"><font size=100000>IT LIVESSSSSSSSSSSS</font></p>
</html>