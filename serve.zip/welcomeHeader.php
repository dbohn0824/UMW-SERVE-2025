<!-- This looks really, really great!  -Thomas -->

<?php
/*
 * Copyright 2013 by Allen Tucker. 
 * This program is part of RMHP-Homebase, which is free software.  It comes with 
 * absolutely no warranty. You can redistribute and/or modify it under the terms 
 * of the GNU General Public License as published by the Free Software Foundation
 * (see <http://www.gnu.org/licenses/ for more information).
 * 
 */
?>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</head>

<header>

    <?PHP
        echo '
        <nav>
            <span id="nav-top">
                <span class="logo">
                    <img src="images/SERVE_logo.png">
                    <span id="vms-logo">  SERVE </span>
                </span>
            </span>
        </nav>';

    ?>
</header>
<!--
<header>
    <nav>
        <div id="nav-top" class="container">
            <div class="logo">
                <img src="images/SERVE_logo.png" alt="Logo">
                <span id="vms-logo">SERVE</span>
            </div>
        </div>
    </nav>
</header>  --> 