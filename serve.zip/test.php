<?php

include_once(__DIR__ . '/database/dbinfo.php');  // Include dbinfo.php from the 'database' folder
include_once(__DIR__ . '/domain/Person.php');  // Include Person.php from the root folder
include_once(__DIR__ . '/database/dbPersons.php');

$endTime = date('D M Y');

$result = check_out("Thall1", $endTime ); 

var_dump($result); 
?> 